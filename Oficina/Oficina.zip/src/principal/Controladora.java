package principal;

import visualizacao.EntradaSaida;

public class Controladora {
	
	public void exibeMenu() {
		
		int opcao;
		
		do {
			opcao = EntradaSaida.solicitaOpcao();
			
			switch(opcao) {
			
			case 0:
				
				
				break;
			}
			
		} while (opcao != 1);
		
	}

}
